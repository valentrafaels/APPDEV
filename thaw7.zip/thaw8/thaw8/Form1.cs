﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thaw8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] untukambilfilm = File.ReadAllLines(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\listfilm.txt");
        Button[,] forshowtime = new Button[8,3]; //8 untuk jumlah film, 3 jumlah showtime
        int x = 190; //untuk kesamping
        int y = 130; //untuk kebawah
        int jam = 8;


        public static int counter2 = 0;
        public static List<int> merah2 = new List<int>();
        public static List<string> hijau2 = new List<string>();

        public static int counter3 = 0;
        public static List<int> merah3 = new List<int>();
        public static List<string> hijau3 = new List<string>();

        public static int counter4 = 0;
        public static List<int> merah4 = new List<int>();
        public static List<string> hijau4 = new List<string>();

        public static int counter5 = 0;
        public static List<int> merah5 = new List<int>();
        public static List<string> hijau5 = new List<string>();

        public static int counter6 = 0;
        public static List<int> merah6 = new List<int>();
        public static List<string> hijau6 = new List<string>();

        public static int counter7 = 0;
        public static List<int> merah7 = new List<int>();
        public static List<string> hijau7 = new List<string>();

        public static int counter8 = 0;
        public static List<int> merah8 = new List<int>();
        public static List<string> hijau8 = new List<string>();

        public static int counter9 = 0;
        public static List<int> merah9 = new List<int>();
        public static List<string> hijau9 = new List<string>();

        public static int counter10 = 0;
        public static List<int> merah10 = new List<int>();
        public static List<string> hijau10 = new List<string>();

        public static int counter11 = 0;
        public static List<int> merah11 = new List<int>();
        public static List<string> hijau11 = new List<string>();

        public static int counter12 = 0;
        public static List<int> merah12 = new List<int>();
        public static List<string> hijau12 = new List<string>();

        public static int counter13 = 0;
        public static List<int> merah13 = new List<int>();
        public static List<string> hijau13 = new List<string>();

        public static int counter14 = 0;
        public static List<int> merah14 = new List<int>();
        public static List<string> hijau14 = new List<string>();

        public static int counter15 = 0;
        public static List<int> merah15 = new List<int>();
        public static List<string> hijau15 = new List<string>();

        public static int counter16 = 0;
        public static List<int> merah16 = new List<int>();
        public static List<string> hijau16 = new List<string>();

        public static int counter17 = 0;
        public static List<int> merah17 = new List<int>();
        public static List<string> hijau17 = new List<string>();

        public static int counter18 = 0;
        public static List<int> merah18 = new List<int>();
        public static List<string> hijau18 = new List<string>();

        public static int counter19 = 0;
        public static List<int> merah19 = new List<int>();
        public static List<string> hijau19 = new List<string>();

        public static int counter20 = 0;
        public static List<int> merah20 = new List<int>();
        public static List<string> hijau20 = new List<string>();

        public static int counter21 = 0;
        public static List<int> merah21 = new List<int>();
        public static List<string> hijau21 = new List<string>();

        public static int counter22 = 0;
        public static List<int> merah22 = new List<int>();
        public static List<string> hijau22 = new List<string>();

        public static int counter23 = 0;
        public static List<int> merah23 = new List<int>();
        public static List<string> hijau23 = new List<string>();

        public static int counter24 = 0;
        public static List<int> merah24 = new List<int>();
        public static List<string> hijau24 = new List<string>();

        public static int counter25 = 0;
        public static List<int> merah25 = new List<int>();
        public static List<string> hijau25 = new List<string>();

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] subs = untukambilfilm[0].Split(',');
            PictureBox picturebox = new PictureBox();
            picturebox.Image = Image.FromFile(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\Despicable Me.jpg");
            picturebox.SizeMode = PictureBoxSizeMode.StretchImage;
            picturebox.Location = new Point(80, 80);
            picturebox.Size = new Size(100, 100);
            this.Controls.Add(picturebox); 
            Label label1 = new Label();
            label1.Location = new Point(90, 180);
            label1.Text = subs[0];
            label1.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label1);

            PictureBox picturebox2 = new PictureBox();
            picturebox2.Image = Image.FromFile(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\Sing.jpg");
            picturebox2.SizeMode = PictureBoxSizeMode.StretchImage;
            picturebox2.Location = new Point(80, 210);
            picturebox2.Size = new Size(100, 100);
            this.Controls.Add(picturebox2);
            Label label2 = new Label();
            label2.Location = new Point(90, 310);
            label2.Text = subs[1];
            label2.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label2);


            PictureBox picture3 = new PictureBox();
            picture3.Image = Image.FromFile(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\Nemo.jpg");
            picture3.SizeMode = PictureBoxSizeMode.StretchImage;
            picture3.Location = new Point(80, 340);
            picture3.Size = new Size(100, 100);
            this.Controls.Add(picture3);
            Label label3 = new Label();
            label3.Location = new Point(90, 440);
            label3.Text = subs[2];
            label3.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label3);

            
            PictureBox picturebox4 = new PictureBox();
            picturebox4.Image = Image.FromFile(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\Frozen.jpg");
            picturebox4.SizeMode = PictureBoxSizeMode.StretchImage;
            picturebox4.Location = new Point(80, 470);
            picturebox4.Size = new Size(100, 100);
            this.Controls.Add(picturebox4);
            Label label4 = new Label();
            label4.Location = new Point(90, 570);
            label4.Text = subs[3];
            label4.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label4);

            PictureBox picturebox5 = new PictureBox();
            picturebox5.Image = Image.FromFile(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\Cars.jpg");
            picturebox5.SizeMode = PictureBoxSizeMode.StretchImage;
            picturebox5.Location = new Point(500, 80);
            picturebox5.Size = new Size(100, 100);
            this.Controls.Add(picturebox5);
            Label label5 = new Label();
            label5.Location = new Point(510, 180);
            label5.Text = subs[4];
            label5.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label5);


            PictureBox picturebox6 = new PictureBox();
            picturebox6.Image = Image.FromFile(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\Madagascar.jpg");
            picturebox6.SizeMode = PictureBoxSizeMode.StretchImage;
            picturebox6.Location = new Point(500, 210);
            picturebox6.Size = new Size(100, 100);
            this.Controls.Add(picturebox6);
            Label label6 = new Label();
            label6.Location = new Point(510, 310);
            label6.Text = subs[5];
            label6.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label6);


            PictureBox picturebox7 = new PictureBox();
            picturebox7.Image = Image.FromFile(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\Minions.jpg");
            picturebox7.SizeMode = PictureBoxSizeMode.StretchImage;
            picturebox7.Location = new Point(500, 340);
            picturebox7.Size = new Size(100, 100);
            this.Controls.Add(picturebox7);
            Label label7 = new Label();
            label7.Location = new Point(510, 440);
            label7.Text = subs[6];
            label7.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label7);


            PictureBox picturebox8 = new PictureBox();
            picturebox8.Image = Image.FromFile(@"C:\Users\valentrafael\source\repos\thaw8\thaw8\formovie\Peterpan.jpg");
            picturebox8.SizeMode = PictureBoxSizeMode.StretchImage;
            picturebox8.Location = new Point(500, 470);
            picturebox8.Size = new Size(100, 100);
            this.Controls.Add(picturebox8);
            Label label8 = new Label();
            label8.Location = new Point(510, 570);
            label8.Text = subs[7];
            label8.Font = new Font("Microsoft YaHei", 10);
            this.Controls.Add(label8);

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    forshowtime[i, j] = new Button();
                    forshowtime[i, j].Location = new Point(x, y);
                    forshowtime[i, j].Text = jam.ToString();
                    forshowtime[i, j].Tag = i + "," + j;
                    forshowtime[i, j].Click += button_click;
                    this.Controls.Add(forshowtime[i, j]);
                    jam += 2; 
                    x += 100;
                }
                if (i < 3) 
                {
                    x = 190;
                    y += 130; 
                    jam = 8;
                }
                if (i == 3)
                {
                    x = 610;
                    y = 130;
                    jam = 8;
                }
                if (i > 3)
                {
                    x = 610;
                    y += 130;
                    jam = 8;
                }
            }
        }
        private void button_click(object sender, EventArgs e)
        {
            var buttonclick = sender as Button;
            string[] separate = buttonclick.Tag.ToString().Split(',');
            if (separate[0] == "0" && separate[1] == "0")
            {
                Form2 form2 = new Form2();
                form2.Dock = DockStyle.Fill;
                form2.TopLevel = false;
                this.panel1.Controls.Add(form2);
                form2.Show();
            }
            if (separate[0] == "0" && separate[1] == "1")
            {
                Form3 form3 = new Form3();
                form3.Dock = DockStyle.Fill;
                form3.TopLevel = false;
                this.panel1.Controls.Add(form3);
                form3.Show();
            }
            if (separate[0] == "0" && separate[1] == "2")
            {
                Form4 form4 = new Form4();
                form4.Dock = DockStyle.Fill;
                form4.TopLevel = false;
                this.panel1.Controls.Add(form4);
                form4.Show();
            }
            if (separate[0] == "1" && separate[1] == "0")
            {
                Form5 form5 = new Form5();
                form5.Dock = DockStyle.Fill;
                form5.TopLevel = false;
                this.panel1.Controls.Add(form5);
                form5.Show();
            }
            if (separate[0] == "1" && separate[1] == "1")
            {
                Form6 form6 = new Form6();
                form6.Dock = DockStyle.Fill;
                form6.TopLevel = false;
                this.panel1.Controls.Add(form6);
                form6.Show();
            }
            if (separate[0] == "1" && separate[1] == "2")
            {
                Form7 form7 = new Form7();
                form7.Dock = DockStyle.Fill;
                form7.TopLevel = false;
                this.panel1.Controls.Add(form7);
                form7.Show();
            }
            if (separate[0] == "2" && separate[1] == "0")
            {
                Form8 form8 = new Form8();
                form8.Dock = DockStyle.Fill;
                form8.TopLevel = false;
                this.panel1.Controls.Add(form8);
                form8.Show();
            }
            if (separate[0] == "2" && separate[1] == "1")
            {
                Form9 form9 = new Form9();
                form9.Dock = DockStyle.Fill;
                form9.TopLevel = false;
                this.panel1.Controls.Add(form9);
                form9.Show();
            }
            if (separate[0] == "2" && separate[1] == "2")
            {
                Form10 form10 = new Form10();
                form10.Dock = DockStyle.Fill;
                form10.TopLevel = false;
                this.panel1.Controls.Add(form10);
                form10.Show();
            }
            if (separate[0] == "3" && separate[1] == "0")
            {
                Form11 form11 = new Form11();
                form11.Dock = DockStyle.Fill;
                form11.TopLevel = false;
                this.panel1.Controls.Add(form11);
                form11.Show();
            }
            if (separate[0] == "3" && separate[1] == "1")
            {
                Form12 form12 = new Form12();
                form12.Dock = DockStyle.Fill;
                form12.TopLevel = false;
                this.panel1.Controls.Add(form12);
                form12.Show();
            }
            if (separate[0] == "3" && separate[1] == "2")
            {
                Form13 form13 = new Form13();
                form13.Dock = DockStyle.Fill;
                form13.TopLevel = false;
                this.panel1.Controls.Add(form13);
                form13.Show();
            }

            if (separate[0] == "4" && separate[1] == "0")
            {
                Form14 form14 = new Form14();
                form14.Dock = DockStyle.Fill;
                form14.TopLevel = false;
                this.panel1.Controls.Add(form14);
                form14.Show();
            }
            if (separate[0] == "4" && separate[1] == "1")
            {
                Form15 form15 = new Form15();
                form15.Dock = DockStyle.Fill;
                form15.TopLevel = false;
                this.panel1.Controls.Add(form15);
                form15.Show();
            }
            if (separate[0] == "4" && separate[1] == "2")
            {
                Form16 form16 = new Form16();
                form16.Dock = DockStyle.Fill;
                form16.TopLevel = false;
                this.panel1.Controls.Add(form16);
                form16.Show();
            }
            if (separate[0] == "5" && separate[1] == "0")
            {
                Form17 form17 = new Form17();
                form17.Dock = DockStyle.Fill;
                form17.TopLevel = false;
                this.panel1.Controls.Add(form17);
                form17.Show();
            }
            if (separate[0] == "5" && separate[1] == "1")
            {
                Form18 form18 = new Form18();
                form18.Dock = DockStyle.Fill;
                form18.TopLevel = false;
                this.panel1.Controls.Add(form18);
                form18.Show();
            }
            if (separate[0] == "5" && separate[1] == "2")
            {
                Form19 form19 = new Form19();
                form19.Dock = DockStyle.Fill;
                form19.TopLevel = false;
                this.panel1.Controls.Add(form19);
                form19.Show();
            }
            if (separate[0] == "6" && separate[1] == "0")
            {
                Form20 form20 = new Form20();
                form20.Dock = DockStyle.Fill;
                form20.TopLevel = false;
                this.panel1.Controls.Add(form20);
                form20.Show();
            }
            if (separate[0] == "6" && separate[1] == "1")
            {
                Form21 form21 = new Form21();
                form21.Dock = DockStyle.Fill;
                form21.TopLevel = false;
                this.panel1.Controls.Add(form21);
                form21.Show();
            }
            if (separate[0] == "6" && separate[1] == "2")
            {
                Form22 form22 = new Form22();
                form22.Dock = DockStyle.Fill;
                form22.TopLevel = false;
                this.panel1.Controls.Add(form22);
                form22.Show();
            }
            if (separate[0] == "7" && separate[1] == "0")
            {
                Form23 form23 = new Form23();
                form23.Dock = DockStyle.Fill;
                form23.TopLevel = false;
                this.panel1.Controls.Add(form23);
                form23.Show();
            }
            //if (pemisahtagpadabuttonshowtime[0] == "7" && pemisahtagpadabuttonshowtime[1] == "1")
            //{
            //    Form24 form24 = new Form24();
            //    form24.Dock = DockStyle.Fill;
            //    form24.TopLevel = false;
            //    this.panel_container.Controls.Add(form24);
            //    form24.Show();
            //}
            //if (pemisahtagpadabuttonshowtime[0] == "7" && pemisahtagpadabuttonshowtime[1] == "2")
            //{
            //    Form25 form25 = new Form25();
            //    form25.Dock = DockStyle.Fill;
            //    form25.TopLevel = false;
            //    this.panel_container.Controls.Add(form25);
            //    form25.Show();
            //}
        }
    }
}

