﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thaw8
{
    public partial class Form19 : Form
    {
        public Form19()
        {
            InitializeComponent();
        }

        Random random = new Random();
        Button[,] buttonfield = new Button[10, 10];
        int x = 10;
        int y = 10;

        List<Color> possibleColors = new List<Color>()
        {
            Color.Red,
            Color.Gray

        };
        private Color GetRandomColorOfList()
        {
            return possibleColors[random.Next(0, possibleColors.Count)];
        }
        private void button_click(object sender, EventArgs e)
        {
            var btnclick = sender as Button;

            if (btnclick.BackColor == Color.Gray)
            {
                btnclick.BackColor = Color.Green;
                string[] split = btnclick.Tag.ToString().Split(',');
                Form1.hijau19.Add(split[0] + "," + split[1] + "," + split[2]);
            }
            else if (btnclick.BackColor == Color.Red)
            {
                MessageBox.Show("Seat sudah di ambil!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Button b in buttonfield)
            {
                if (b.BackColor == Color.Green)
                {
                    b.BackColor = Color.Gray;
                    string[] split = b.Tag.ToString().Split(',');
                    Form1.hijau19.Remove(split[0] + "," + split[1] + "," + split[2]);
                }
            }
        }

        private void Form19_Load(object sender, EventArgs e)
        {
            if (Form1.counter19 == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        buttonfield[i, j] = new Button();
                        buttonfield[i, j].Location = new Point(x, y);
                        buttonfield[i, j].Size = new Size(20, 20);
                        buttonfield[i, j].BackColor = GetRandomColorOfList();
                        buttonfield[i, j].Click += button_click;
                        buttonfield[i, j].Tag = i + "," + j + ",BELUM ADA!";
                        this.Controls.Add(buttonfield[i, j]);
                        x += 30;
                    }

                    y += 30;
                    x = 10;
                }
                int count = 0;
                foreach (Button b in buttonfield)
                {
                    if (b.BackColor == Color.Red)
                    {
                        Form1.merah19.Add(count);
                    }
                    count++;
                }
            }

            if (Form1.counter19 > 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        buttonfield[i, j] = new Button();
                        buttonfield[i, j].Location = new Point(x, y);
                        buttonfield[i, j].Size = new Size(20, 20);
                        buttonfield[i, j].Click += button_click;
                        buttonfield[i, j].BackColor = Color.Gray;
                        buttonfield[i, j].Tag = i + "," + j + ",BELUM ADA!";
                        this.Controls.Add(buttonfield[i, j]);
                        x += 30;
                    }

                    y += 30;
                    x = 10;
                }
                int count1 = 0;
                foreach (int n in Form1.merah19)
                {
                    foreach (Button b in buttonfield)
                    {
                        if (n == count1)
                        {
                            b.BackColor = Color.Red;
                        }
                        count1++;
                    }
                    count1 = 0;
                }
                foreach (string u in Form1.hijau19)
                {
                    foreach (Button b in buttonfield)
                    {
                        if (u == b.Tag.ToString())
                        {
                            b.BackColor = Color.Green;
                        }
                    }
                }
            }
            Form1.counter19++;
        }
    }
}
