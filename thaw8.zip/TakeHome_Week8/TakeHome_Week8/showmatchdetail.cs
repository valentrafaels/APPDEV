﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using MySql.Data.MySqlClient;
namespace TakeHome_Week8
{
    public partial class showmatchdetail : Form
    {
        MySqlConnection SqlConnection;
        MySqlCommand SqlCommand;
        MySqlDataAdapter SqlDataAdapter;
        string connection = "server=localhost;uid=root;pwd=;database=premier_league;", query;
        DataTable dtTeam = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtInfoPlayer = new DataTable();
        string home = "";
        string away = "";
        public showmatchdetail()
        {
            InitializeComponent();
            SqlConnection = new MySqlConnection(connection);
        }

        private void comboBox1_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtPlayer = new DataTable();
            query = $"select m.match_date ,m.match_id from team t1,team t2, premier_league.match m where t1.team_id=m.team_home and t2.team_id=m.team_away and (t1.team_name='{comboBox1_team.Text}' or t2.team_name='{comboBox1_team.Text}');";
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            dtPlayer = new DataTable();
            SqlDataAdapter.Fill(dtPlayer);
            comboBox2_matchdate.DataSource = dtPlayer;
            comboBox2_matchdate.DisplayMember = "match_date";
            comboBox2_matchdate.ValueMember = "match_id";
        }

        private void comboBox2_matchdate_SelectedIndexChanged(object sender, EventArgs e)
        {
            query = $"select t1.team_name as 't1', t2.team_name as 't2' from premier_league.match m, team t1, team t2 where m.team_home = t1.team_id and m.team_away = t2.team_id and m.match_id = '{comboBox2_matchdate.SelectedValue.ToString()}';";
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            dtInfoPlayer = new DataTable();
            SqlDataAdapter.Fill(dtInfoPlayer);
            home = dtInfoPlayer.Rows[0][0].ToString();
            away= dtInfoPlayer.Rows[0][1].ToString();
            query = $"select t.team_name, p.player_name,p.playing_pos from player p, team t where p.team_id=t.team_id and (t.team_name='{home}' or t.team_name='{away}');";
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            dtInfoPlayer = new DataTable();
            SqlDataAdapter.Fill(dtInfoPlayer);
            dataGridView_player.DataSource=dtInfoPlayer;
            query = $"SELECT d.minute as'minute',t.team_name as'team name',p.player_name as'player name',d.type as 'type' FROM dmatch d,team t,player p WHERE d.team_id=t.team_id AND d.player_id=p.player_id AND d.match_id='{comboBox2_matchdate.SelectedValue.ToString()}';";
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            dtInfoPlayer = new DataTable();
            SqlDataAdapter.Fill(dtInfoPlayer);
            for(int a=0; a<dtInfoPlayer.Rows.Count; a++)
            {
                switch (dtInfoPlayer.Rows[a][3].ToString())
                {
                    case "CY":
                        dtInfoPlayer.Rows[a][3] = "Yellow Card";
                        break;
                    case "CR":
                        dtInfoPlayer.Rows[a][3] = "Red Card";
                        break;
                    case "GO":
                        dtInfoPlayer.Rows[a][3] = "Goal";
                        break;
                    case "PM":
                        dtInfoPlayer.Rows[a][3] = "Penalty Missed";
                        break;
                }
            }
            dataGridView_match.DataSource=dtInfoPlayer;
        }

        private void showmatchdetail_Load(object sender, EventArgs e)
        {
            query = "select team_name from team;";
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            SqlDataAdapter.Fill(dtTeam);
            comboBox1_team.DataSource = dtTeam;
            comboBox1_team.DisplayMember = "team_name";
        }
    }
}
