﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace TakeHome_Week8
{
    public partial class playerdata : Form
    {
        MySqlConnection SqlConnection;
        MySqlCommand SqlCommand;
        MySqlDataAdapter SqlDataAdapter;
        string connection= "server=localhost;uid=root;pwd=;database=premier_league;", query;
        DataTable dtTeam = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtInfoPlayer = new DataTable();
        public playerdata()
        {
            InitializeComponent();
        }

        private void playerdata_Load(object sender, EventArgs e)
        {
            SqlConnection = new MySqlConnection(connection);
            query = "select team_name from team;";
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            SqlDataAdapter.Fill(dtTeam);
            comboBox1_team.DataSource = dtTeam;
            comboBox1_team.DisplayMember = "team_name";
        }

        private void comboBox2_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection = new MySqlConnection(connection);
            query = $"select p.player_name,t.team_name,p.playing_pos,n.nation,p.team_number from player p,nationality n, team t where t.team_name ='{comboBox1_team.Text}' and p.player_name='{comboBox2_player.Text}' and p.team_id=t.team_id  and n.nationality_id=p.nationality_id;";
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            dtInfoPlayer = new DataTable();
            SqlDataAdapter.Fill(dtInfoPlayer);
            label_player.Text = Convert.ToString(dtInfoPlayer.Rows[0][0]);
            label_team.Text = Convert.ToString(dtInfoPlayer.Rows[0][1]);
            label_position.Text= Convert.ToString(dtInfoPlayer.Rows[0][2]);
            label_nation.Text = Convert.ToString(dtInfoPlayer.Rows[0][3]);
            label_squadnumber.Text= Convert.ToString(dtInfoPlayer.Rows[0][4]);
            dtInfoPlayer = new DataTable();
            query = $"select d.type from dmatch d,player p where p.player_name='{comboBox2_player.Text}' and p.player_id=d.player_id;";
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            SqlDataAdapter.Fill(dtInfoPlayer);
            int yellow=0, red=0, goal = 0, penalty = 0;
            for (int a = 0; a < dtInfoPlayer.Rows.Count; a++)
            {
                switch(dtInfoPlayer.Rows[a][0].ToString())
                {
                    case "CY":
                        yellow++;
                        break;
                    case "CR":
                        red++;
                        break;
                    case "GO":
                        goal++;
                        break;
                    case "PM":
                        penalty += 1;
                        break;
                }
                if(a== dtInfoPlayer.Rows.Count-1)
                {
                    label_yellowc.Text = Convert.ToString(yellow);
                    label_redc.Text = Convert.ToString(red);
                    label_goals.Text = Convert.ToString(goal);
                    label_penaltymiss.Text = Convert.ToString(penalty);
                }
            }
        }

        private void comboBox1_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection = new MySqlConnection(connection);
            query = $"select p.player_name as 'name' from player p,team t where t.team_name='{comboBox1_team.Text}' and p.team_id=t.team_id ;"; ;
            SqlCommand = new MySqlCommand(query, SqlConnection);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            dtPlayer = new DataTable();
            SqlDataAdapter.Fill(dtPlayer);
            comboBox2_player.DataSource = dtPlayer;
            comboBox2_player.DisplayMember = "name";
        }
    }
}
