﻿namespace TakeHome_Week8
{
    partial class playerdata
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1_team = new System.Windows.Forms.ComboBox();
            this.comboBox2_player = new System.Windows.Forms.ComboBox();
            this.label_squadnumber = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_penaltymiss = new System.Windows.Forms.Label();
            this.label_goals = new System.Windows.Forms.Label();
            this.label_redc = new System.Windows.Forms.Label();
            this.label_yellowc = new System.Windows.Forms.Label();
            this.label_nation = new System.Windows.Forms.Label();
            this.label_position = new System.Windows.Forms.Label();
            this.label_team = new System.Windows.Forms.Label();
            this.label_player = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(392, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            // 
            // comboBox1_team
            // 
            this.comboBox1_team.FormattingEnabled = true;
            this.comboBox1_team.Location = new System.Drawing.Point(12, 12);
            this.comboBox1_team.Name = "comboBox1_team";
            this.comboBox1_team.Size = new System.Drawing.Size(121, 21);
            this.comboBox1_team.TabIndex = 1;
            this.comboBox1_team.SelectedIndexChanged += new System.EventHandler(this.comboBox1_team_SelectedIndexChanged);
            // 
            // comboBox2_player
            // 
            this.comboBox2_player.FormattingEnabled = true;
            this.comboBox2_player.Location = new System.Drawing.Point(161, 12);
            this.comboBox2_player.Name = "comboBox2_player";
            this.comboBox2_player.Size = new System.Drawing.Size(121, 21);
            this.comboBox2_player.TabIndex = 2;
            this.comboBox2_player.SelectedIndexChanged += new System.EventHandler(this.comboBox2_player_SelectedIndexChanged);
            // 
            // label_squadnumber
            // 
            this.label_squadnumber.AutoSize = true;
            this.label_squadnumber.Location = new System.Drawing.Point(746, 71);
            this.label_squadnumber.Name = "label_squadnumber";
            this.label_squadnumber.Size = new System.Drawing.Size(10, 13);
            this.label_squadnumber.TabIndex = 71;
            this.label_squadnumber.Text = ".";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(645, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 70;
            this.label2.Text = "Squad Number :";
            // 
            // label_penaltymiss
            // 
            this.label_penaltymiss.AutoSize = true;
            this.label_penaltymiss.Location = new System.Drawing.Point(561, 117);
            this.label_penaltymiss.Name = "label_penaltymiss";
            this.label_penaltymiss.Size = new System.Drawing.Size(13, 13);
            this.label_penaltymiss.TabIndex = 69;
            this.label_penaltymiss.Text = "0";
            // 
            // label_goals
            // 
            this.label_goals.AutoSize = true;
            this.label_goals.Location = new System.Drawing.Point(406, 117);
            this.label_goals.Name = "label_goals";
            this.label_goals.Size = new System.Drawing.Size(13, 13);
            this.label_goals.TabIndex = 68;
            this.label_goals.Text = "0";
            // 
            // label_redc
            // 
            this.label_redc.AutoSize = true;
            this.label_redc.Location = new System.Drawing.Point(234, 117);
            this.label_redc.Name = "label_redc";
            this.label_redc.Size = new System.Drawing.Size(13, 13);
            this.label_redc.TabIndex = 67;
            this.label_redc.Text = "0";
            // 
            // label_yellowc
            // 
            this.label_yellowc.AutoSize = true;
            this.label_yellowc.Location = new System.Drawing.Point(78, 117);
            this.label_yellowc.Name = "label_yellowc";
            this.label_yellowc.Size = new System.Drawing.Size(13, 13);
            this.label_yellowc.TabIndex = 66;
            this.label_yellowc.Text = "0";
            // 
            // label_nation
            // 
            this.label_nation.AutoSize = true;
            this.label_nation.Location = new System.Drawing.Point(561, 71);
            this.label_nation.Name = "label_nation";
            this.label_nation.Size = new System.Drawing.Size(10, 13);
            this.label_nation.TabIndex = 65;
            this.label_nation.Text = ".";
            // 
            // label_position
            // 
            this.label_position.AutoSize = true;
            this.label_position.Location = new System.Drawing.Point(409, 71);
            this.label_position.Name = "label_position";
            this.label_position.Size = new System.Drawing.Size(10, 13);
            this.label_position.TabIndex = 64;
            this.label_position.Text = ".";
            // 
            // label_team
            // 
            this.label_team.AutoSize = true;
            this.label_team.Location = new System.Drawing.Point(228, 71);
            this.label_team.Name = "label_team";
            this.label_team.Size = new System.Drawing.Size(10, 13);
            this.label_team.TabIndex = 63;
            this.label_team.Text = ".";
            // 
            // label_player
            // 
            this.label_player.AutoSize = true;
            this.label_player.Location = new System.Drawing.Point(82, 71);
            this.label_player.Name = "label_player";
            this.label_player.Size = new System.Drawing.Size(10, 13);
            this.label_player.TabIndex = 62;
            this.label_player.Text = ".";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(471, 117);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 13);
            this.label10.TabIndex = 61;
            this.label10.Text = "Penalty Missed :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(325, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 60;
            this.label9.Text = "Goal Scored :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(176, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 59;
            this.label8.Text = "Red Card :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 117);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 58;
            this.label7.Text = "Yellow Card :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(493, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 57;
            this.label6.Text = "Nationality :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(348, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 56;
            this.label5.Text = "Position :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(176, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 55;
            this.label4.Text = "Team :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 54;
            this.label3.Text = "Player Name :";
            // 
            // playerdata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_squadnumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_penaltymiss);
            this.Controls.Add(this.label_goals);
            this.Controls.Add(this.label_redc);
            this.Controls.Add(this.label_yellowc);
            this.Controls.Add(this.label_nation);
            this.Controls.Add(this.label_position);
            this.Controls.Add(this.label_team);
            this.Controls.Add(this.label_player);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox2_player);
            this.Controls.Add(this.comboBox1_team);
            this.Controls.Add(this.label1);
            this.Name = "playerdata";
            this.Text = "playerdata";
            this.Load += new System.EventHandler(this.playerdata_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1_team;
        private System.Windows.Forms.ComboBox comboBox2_player;
        private System.Windows.Forms.Label label_squadnumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_penaltymiss;
        private System.Windows.Forms.Label label_goals;
        private System.Windows.Forms.Label label_redc;
        private System.Windows.Forms.Label label_yellowc;
        private System.Windows.Forms.Label label_nation;
        private System.Windows.Forms.Label label_position;
        private System.Windows.Forms.Label label_team;
        private System.Windows.Forms.Label label_player;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}