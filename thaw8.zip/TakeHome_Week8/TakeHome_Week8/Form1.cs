﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace TakeHome_Week8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripLabel_playerdata_Click(object sender, EventArgs e)
        {
            panel.Controls.Clear();
            playerdata playerdata= new playerdata();
            playerdata.TopLevel = false;
            playerdata.ControlBox = false;
            playerdata.Dock = DockStyle.Fill;
            playerdata.FormBorderStyle= FormBorderStyle.None;
            panel.Controls.Add(playerdata);
            playerdata.Show();
        }

        private void toolStripLabel_showmatchdetail_Click(object sender, EventArgs e)
        {
            panel.Controls.Clear();
            showmatchdetail showmatchdetail = new showmatchdetail();
            showmatchdetail.TopLevel = false;
            showmatchdetail.ControlBox = false;
            showmatchdetail.Dock = DockStyle.Fill;
            showmatchdetail.FormBorderStyle= FormBorderStyle.None;
            panel.Controls.Add(showmatchdetail);
            showmatchdetail.Show();
        }
    }
}
